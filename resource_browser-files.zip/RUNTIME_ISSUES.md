# Runtime Issues & Fixes

## Issue: RenderFlex Overflow (FIXED)

### Problem
```
A RenderFlex overflowed by 82 pixels on the bottom
```

Yellow and black striped pattern appears on resource cards.

### Cause
The content (icon + text + badge) was too large for the available card space.

### Solution Applied
✅ **Fixed in the code!** Changes made:

1. **Reduced padding** in cards (16px → 8px)
2. **Smaller icon size** (48px → 36px)
3. **Smaller text** (14px → 12px)
4. **Smaller badge** (10px → 9px)
5. **Added Flexible widget** around text to allow shrinking
6. **Changed aspect ratio** (1.5 → 1.2) for taller cards
7. **Used mainAxisSize: MainAxisSize.min** to prevent expansion

### How to Apply the Fix

If you're using the original code, just press **'R'** (capital R) in your terminal to hot restart the app. The overflow should be gone!

If you still see issues:
1. Stop the app (press 'q' or Ctrl+C)
2. Run `flutter run -d chrome` again
3. The updated code will load

## Other Common Runtime Issues

### Issue: "No resources found"

**Symptoms:**
- Empty screen with folder icon
- Message: "No resources found"

**Cause:**
- Manifest file doesn't exist
- Manifest file is empty
- File paths are incorrect

**Fix:**
```bash
# 1. Check if manifest exists
ls web/resources_manifest.txt

# 2. Check content
cat web/resources_manifest.txt

# 3. Verify files exist
ls web/resources/

# 4. Make sure paths match exactly
```

### Issue: Video won't play

**Symptoms:**
- Error icon appears
- "Failed to load video" message

**Possible Causes & Fixes:**

1. **Wrong format**
   - ✅ Supported: MP4, WebM, OGG
   - ❌ Not supported: AVI, MOV, WMV
   - Fix: Convert to MP4

2. **File path wrong**
   - Check manifest file
   - Ensure path matches actual file location
   
3. **CORS issue (if loading from external URL)**
   - Files must be on same domain
   - Or server must allow CORS

### Issue: PDF won't load

**Symptoms:**
- Blank screen
- Error message in snackbar

**Possible Causes & Fixes:**

1. **Corrupted PDF**
   - Try opening PDF in browser directly
   - Try a different PDF

2. **Large PDF**
   - May take time to load
   - Wait a few seconds
   - Check browser console (F12) for errors

3. **Path issue**
   - Verify path in manifest
   - Check file exists

### Issue: Markdown not formatting

**Symptoms:**
- Plain text appears
- No formatting (bold, headers, etc.)

**Cause:**
- File loaded but not parsed as markdown
- Usually means the viewer is working correctly

**Check:**
1. File extension is .md or .markdown
2. Content has markdown syntax
3. File is being detected as type 'markdown'

### Issue: Layout looks weird on small screens

**Current Behavior:**
- App is desktop-first
- May not look good on small screens

**Temporary Fix:**
- Maximize browser window
- Use on desktop/laptop

**Future Enhancement:**
Will add responsive breakpoints for mobile/tablet.

### Issue: Hot reload not working

**Symptoms:**
- Changes don't appear
- Press 'r' but nothing happens

**Fix:**
1. Try 'R' (capital) for hot restart instead
2. Or stop and restart: `flutter run -d chrome`

### Issue: Performance is slow

**If you have many files (100+):**

Current version loads all at once. Future enhancements will add:
- Pagination
- Lazy loading
- Virtual scrolling

**Temporary solutions:**
- Reduce number of files
- Split into multiple manifests
- Use folders (future feature)

## Debugging Tips

### View Browser Console

Press **F12** in Chrome/Edge to see:
- Error messages
- Network requests
- Console logs

Useful for diagnosing:
- File loading issues
- JavaScript errors
- Network problems

### Check Network Tab

In browser DevTools:
1. Press F12
2. Click "Network" tab
3. Reload app
4. See which files load/fail

### Flutter DevTools

Click the DevTools link in terminal:
```
http://127.0.0.1:9101?uri=http://...
```

Useful for:
- Widget inspector
- Performance profiling
- Memory analysis

## Quick Fixes Summary

| Problem | Quick Fix |
|---------|-----------|
| Overflow error | Hot restart (R) - already fixed |
| No resources | Check manifest file |
| File won't load | Verify path and file exists |
| Can't see changes | Hot restart (R) or full restart |
| Performance slow | Reduce number of files |
| Layout broken | Maximize window (desktop-first) |

## Getting Help

If you encounter other issues:

1. **Check browser console** (F12)
2. **Read error messages** carefully
3. **Verify file paths** and manifest
4. **Try with simple test file** (test.md)
5. **Restart the app** completely

## Reporting Issues

When asking for help, provide:
- Error message (exact text)
- What you were doing
- Browser console output (F12)
- Your manifest file content
- Flutter version (`flutter --version`)

---

**Most issues are fixed with:**
1. Checking the manifest file
2. Verifying file paths
3. Restarting the app (R)
4. Looking at browser console (F12)
